<?php
require_once __DIR__ . '/includes/db.php';

echo "Database connected successfully!";
?>